rm -rf ~/.vim
rm -rf ~/.vimrc
rm -rf ~/.gvimrc
